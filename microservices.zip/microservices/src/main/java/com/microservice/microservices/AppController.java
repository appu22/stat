package com.microservice.microservices;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class AppController {
	
	@GetMapping("micro1")
	public String m1() {
		System.out.println("microservice -1 ");
		
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> responseEntity = restTemplate.getForEntity("http://localhost:9902/micro2", String.class);
		
		String response = responseEntity.getBody();
		
		return "success - micro1 "+response;
		
	}

}
