package com.microservice.microservices2;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Appcontroller {
	
	@GetMapping("micro2")
	public String m1() {
		
		System.out.println("microservice -2 ");
		
		
		
		return "Success - app2";
	}

}
