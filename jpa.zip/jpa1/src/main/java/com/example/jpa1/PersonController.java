package com.example.jpa1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PersonController {

	@Autowired
	private PersonRepo personRepo;

	@RequestMapping(path = "save", method = RequestMethod.POST)
	public Person save(@RequestBody Person person) {
		personRepo.save(person);
		return person;
	}

//	@RequestMapping(path = "savepersons", method = RequestMethod.POST)
	@PostMapping("/savepersons")
	public String AllPersons(@RequestBody AllPersons persons) {
		personRepo.saveAll(persons.getPerson());
		System.out.println("sdfghj");
		return "Success";
	}

}
