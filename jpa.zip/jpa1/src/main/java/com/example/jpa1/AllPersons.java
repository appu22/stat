package com.example.jpa1;

import java.util.ArrayList;

import java.util.List;

public class AllPersons {

	private List<Person> persons = new ArrayList<Person>();

	public List<Person> getPerson() {
		return persons;
	}

	public void setPerson(List<Person> persons) {
		this.persons = persons;
	}

}
