package com.example.service;

import java.lang.annotation.Annotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.dao.UserDAO;
import com.example.dto.UserDTO;

@Component
public class ServiceImple implements Service {

	@Autowired(required = false)
	private UserDAO dao;

	public void saveValidate(UserDTO dto) {

		try {
			if (!dto.getName().equals("")) {
				System.out.println("inside name validate");
				dao.save(dto);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public Class<? extends Annotation> annotationType() {
		// TODO Auto-generated method stub
		return null;
	}

	public String value() {
		// TODO Auto-generated method stub
		return null;
	}
}
