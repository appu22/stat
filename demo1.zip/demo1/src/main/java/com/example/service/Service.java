package com.example.service;

import org.springframework.stereotype.Component;

import com.example.dto.UserDTO;
@Component
public interface Service {

	void saveValidate(UserDTO dto);

}
