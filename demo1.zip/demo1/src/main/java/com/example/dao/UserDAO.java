package com.example.dao;

import org.springframework.stereotype.Component;

import com.example.dto.UserDTO;
@Component

public interface UserDAO {

	void save(UserDTO dto);

}
