package com.example.dao;

import org.springframework.stereotype.Repository;

import com.example.dto.UserDTO;

@Repository
public class UserDAOImple implements UserDAO {

	public void save(UserDTO dto) {
		System.out.println("Inside save method ");

	}

}
