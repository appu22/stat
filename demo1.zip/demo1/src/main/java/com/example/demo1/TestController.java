package com.example.demo1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.dao.UserDAO;
import com.example.dto.UserDTO;
import com.example.service.Service;

//@RestController
@Controller
@EnableAutoConfiguration
public class TestController {

	@Autowired(required = false)
	UserDAO dao;
	
	@Autowired(required = false)
	Service service;

	@GetMapping("/test")
	public String test(Model model) {
		System.out.println("============");

		model.addAttribute("name", "Hii test..");

		return "index";

	}

	@PostMapping("/test/{name}")
	public String test1(@RequestParam String uname, Model model) {
		System.out.println("============++++++++++++++++");
		model.addAttribute("name" + uname);
		Object attribute = model.getAttribute("uname");
		System.out.println(attribute + " attribute");
		System.out.println("Integer == " + uname);
		return "index";

	}

	@GetMapping("save")
	public String save(Model model) {

		UserDTO dto = new UserDTO("appu", "b");
		UserDTO dto1 = new UserDTO("app", "b");
		
//		dto.setLname("b");
//		dto.setName("appu");
		System.out.println("Last Name  :" + dto);
		service.saveValidate(dto);
		System.out.println("Last Name  :" + dto);
		System.out.println("Name  :" + dto.getName());

		
		return "Saved.."
;	}

}
