package com.example.dto;

import org.springframework.stereotype.Component;


@Component
public class UserDTO {

	private String name;
	private String lname;

	public UserDTO(String name, String lname) {
		super();
		this.name = name;
		this.lname = lname;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	@Override
	public String toString() {
		return "UserDTO [name=" + name + ", lname=" + lname + "]";
	}

}
